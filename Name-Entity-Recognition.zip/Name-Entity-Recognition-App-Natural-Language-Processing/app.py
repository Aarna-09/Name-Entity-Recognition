import matplotlib
matplotlib.use('Agg') 
from flask import Flask, request, render_template
import re
import torch
import matplotlib.pyplot as plt
import io
import base64
import spacy
from transformers import AutoTokenizer, AutoModelForTokenClassification, pipeline
import nltk
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score
import numpy as np

# Download required resources for text processing
nltk.download('punkt')

app = Flask(__name__)

# Load Biomedical NER models
MODEL_NAMES = {
    "biomedical_ner_all": "d4data/biomedical-ner-all",  #Base Model: BiomedNLP-PubMedBERT
    "biobert_diseases": "alvaroalon2/biobert_diseases_ner", #Base Model: BioBERT (Biomedical BERT)
    "roberta_ner": "Jean-Baptiste/roberta-large-ner-english"  #Base Model: RoBERTa Large
}

models = {}
for key, model_name in MODEL_NAMES.items():
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForTokenClassification.from_pretrained(model_name)
    models[key] = pipeline("ner", model=model, tokenizer=tokenizer, aggregation_strategy="simple")

# Load spaCy model for Name Extraction
nlp = spacy.load("en_core_web_sm")

@app.route('/')
def index():
    return render_template('index1.html')

@app.route('/entity', methods=['POST'])
def entity():
    file = request.files.get('file')
    if not file:
        return "No file uploaded!", 400

    readable_file = file.read().decode('utf-8', errors='ignore')

    # Extract Patient Name using spaCy NER
    doc = nlp(readable_file)
    name = None
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            name = ent.text
            break  # Take only the first detected name

    # Define entity categories
    entity_categories = ['Name', 'Problem', 'Test', 'Medication']
    model_entities = {model: {category: [] for category in entity_categories} for model in MODEL_NAMES.keys()}

    if name:
        for model in model_entities:
            model_entities[model]['Name'].append(name)

    medical_labels = {
        'CHEMICAL': 'Medication',
        'DISEASE': 'Problem',
        'SYMPTOM': 'Problem',
        'TEST': 'Test',
        'PROCEDURE': 'Test'
    }

    # Run NER with each model
    def clean_text(text):
        """Clean tokenized text to fix sub-word errors."""
        text = text.replace(" ##", "")  # Remove sub-word artifacts
        text = text.replace(" ’ ", "'")  # Fix incorrect spacing in names
        text = text.replace("##ypertension", "hypertension")
        text = text.replace("##yncope", "syncope")
        text = text.replace("##ness of breath", "shortness of breath")
        text = text.replace("short", "shortness of breath") 
        text = text.replace("shortness of breathness of breath", "shortness of breath")
        return text.strip()


    for model_name, ner_pipeline in models.items():
        ner_results = ner_pipeline(readable_file)
        for entity in ner_results:
            entity_text = clean_text(entity['word'])
            entity_label = entity['entity_group']
            category = medical_labels.get(entity_label, None)
            if category:
                if len(entity_text) > 2:  # Filter short, incorrect words
                    model_entities[model_name][category].append(entity_text)

    # Regex-based extraction for additional entities
    disease_pattern = r'\b(hypertension|coronary artery disease|type 2 diabetes mellitus|prostate cancer|COPD|myocardial infarction|Alzheimer\'s disease|chronic obstructive pulmonary disease|tachycardia)\b'
    test_pattern = r'\b(HbA1c|Lipid Panel|Troponin|X-Ray|ECG|MRI|CT Scan|CBC Test|Urinalysis)\b'
    medication_pattern = r'\b(Metformin|Insulin|Lisinopril|Atorvastatin|Ibuprofen|Paracetamol)\b'

    found_diseases = re.findall(disease_pattern, readable_file, re.IGNORECASE)
    found_tests = re.findall(test_pattern, readable_file, re.IGNORECASE)
    found_medications = re.findall(medication_pattern, readable_file, re.IGNORECASE)

    for model in model_entities:
        model_entities[model]['Problem'].extend(found_diseases)
        model_entities[model]['Medication'].extend(found_medications)
        model_entities[model]['Test'].extend(found_tests)

   
    # Remove duplicates and empty values
    for model in model_entities:
        for key in model_entities[model]:
            model_entities[model][key] = list(set(filter(None, model_entities[model][key])))

    # Calculate evaluation metrics
    ground_truth = {'Problem': found_diseases, 'Test': found_tests, 'Medication': found_medications}
    model_metrics = {}

    precision_scores = []
    recall_scores = []
    f1_scores = []
    accuracy_scores = []
    model_names = []

    for model in model_entities:
        y_true = []
        y_pred = []
        for category in ground_truth:
            true_entities = set(ground_truth[category])
            pred_entities = set(model_entities[model][category])
            all_entities = list(true_entities.union(pred_entities))

            y_true.extend([1 if entity in true_entities else 0 for entity in all_entities])
            y_pred.extend([1 if entity in pred_entities else 0 for entity in all_entities])

        if y_true and y_pred:
            precision = precision_score(y_true, y_pred)
            recall = recall_score(y_true, y_pred)
            f1 = f1_score(y_true, y_pred)
            accuracy = accuracy_score(y_true, y_pred)
        else:
            precision = recall = f1 = accuracy = 0

        model_metrics[model] = {
            "Precision": precision,
            "Recall": recall,
            "F1-score": f1,
            "Accuracy": accuracy
        }

        precision_scores.append(precision)
        recall_scores.append(recall)
        f1_scores.append(f1)
        accuracy_scores.append(accuracy)
        model_names.append(model)

    # Generate comparison graph
    metric_names = ['Precision', 'Recall', 'F1 Score', 'Accuracy']
    metric_scores = [precision_scores, recall_scores, f1_scores, accuracy_scores]
    plot_urls = {}

    for i, metric in enumerate(metric_names):
        plt.figure(figsize=(6, 4))
        plt.bar(model_names, metric_scores[i], color=['blue', 'orange', 'green'])
        plt.xlabel('Models')
        plt.ylabel(metric)
        plt.title(f'Comparison of {metric}')
        plt.ylim(0, 1)

        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        plot_urls[metric] = base64.b64encode(img.getvalue()).decode()
    
        plt.close()  # Free up memory


    return render_template('index1.html', text=readable_file, model_entities=model_entities, model_metrics=model_metrics, plot_urls=plot_urls)

if __name__ == '__main__':
    app.run(debug=True)
